/*
�������򡢿�������ʱ�����
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>
 
#define N 1000000
 
int n[N];
 
//���������
void getRandomNum()
{
    srand(time(0));
    for(int i=0; i<N; i++)
    {
        n[i] = rand()%INT_MAX;
    }
}
 
//��������
void insertSort()
{
    int target;
    for(int i=1; i<N; i++)
    {
        target = n[i];
        //���ֲ��ҽڵ�
        int st=0, ed=i, t;
        while(st != ed)
        {
            if(target == n[(st+ed)/2])
            {
                t = (st+ed)/2;
                break;
            }
            else if(target < n[(st+ed)/2])
            {
                ed = (st+ed)/2;
            }
            else
            {
                st = (st+ed)/2+1;
            }
        }
        t = st==ed?st:t;
 
        for(int j=i; j>t; j--)
        {
            n[j] = n[j-1];
        }
        n[t] = target;
    }
}
 

//��������
void swap(int i, int j)
{
    int t = n[i];
    n[i] = n[j];
    n[j] = t;
}
 
int sort(int st, int ed)
{
    int pivot = n[st];
    int p = st;
 
    for(int i=st+1, j=ed; i<=j;)
    {
        if(pivot > n[i])
        {
            swap(i, p);
            p = i++;
            continue;
        }
        if(pivot <= n[i]) swap(j--, i);
    }
    return p;
}
 
void quickSort(int start, int end)
{
    if(start >= end) return;
 
    int p = sort(start, end);
 
    quickSort(start, p);
    quickSort(p+1, end);
}
 
void testTime()
{
    int time_start, time_end;
 
    getRandomNum();
    time_start = clock();
    quickSort(0, N-1);
    time_end = clock();
    printf("����������ʱ��%d ms\n", time_end-time_start);

	 getRandomNum();
    time_start = clock();
    insertSort();
    time_end = clock();
    printf("����������ʱ��%d ms\n", time_end-time_start);
 
}
 
int main()
{
    testTime();
    return 0;
}
 